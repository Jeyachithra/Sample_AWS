docker build -t google-scraper -f dockerfiles/Dockerfile .
docker run -ti google-scraper

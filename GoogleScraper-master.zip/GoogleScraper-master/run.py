#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Convenience wrapper for running GoogleScrapper directly from source tree."""

from GoogleScraper.core import main

if __name__ == '__main__':
    main()

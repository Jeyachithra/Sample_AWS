# Scraping-AllRecipes
Use Python's Beautiful Soup to first scrape all the recipe URLs, and the scrape the information needed for analysis from each of them. A better and fuller explanation can be found [here](http://derekhodgson.com/project/scraping-allrecipes).

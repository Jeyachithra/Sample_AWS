# Google Text Scraper
 A library to scrap google text results
 
 Pre-requisites:
 1. Pip install Selenium Library
 2. Download Google Chrome 
 3. Download Google Webdriver based on your Chrome version
 
 
Usage: use main.py / juypter_main.ipynb

